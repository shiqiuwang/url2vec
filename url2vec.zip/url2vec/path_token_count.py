"""
返回每一个url的路径中的token的个数，最终要求返回的是每一个url的路径中token个数的ndarray
"""
from get_url import get_url
from urllib.parse import urlparse
import re
import numpy as np

path_token_count_list = []


def get_path_token_count():
    # 获取url数组
    url_array = get_url()
    for url in url_array:
        path = urlparse(url).path
        # print(path)
        path_token_list = re.findall(r"[\w']+", path)
        # print(path_token_list)
        path_token_count_list.append(len(path_token_list))
    path_token_count_array = np.array(path_token_count_list)
    return path_token_count_array

#
# if __name__ == '__main__':
#     path_token_count_array = get_path_token_count()
#     print(path_token_count_array)
#     print(path_token_count_array.shape)
