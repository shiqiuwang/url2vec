"""
输入url 返回url里面对应的文件名拓展名中的字母的个数，最终返回字母个数的数组
"""
# 导入包
import numpy as np
import os
from get_url import get_url
import re


def get_file_extent_name_letter_count():
    # 获取url数组
    url_array = get_url()
    # 用于临时存储文件拓展名中的字母个数的列表
    file_extent_name_letter_count_list = []
    for url in url_array:
        file_extent_name = os.path.splitext(url)[1]
        file_extent_name_letter_count_list.append(len(re.findall('[a-zA-Z]', file_extent_name)))
        # print(file_extent_name)
        # file_extent_name_letter_count_list.append(len(file_extent_name))
    file_extent_name_letter_count_array = np.array(file_extent_name_letter_count_list)
    return file_extent_name_letter_count_array


# # 主函数入口
# if __name__ == '__main__':
#     file_extent_name_letter_count_array = get_file_extent_name_letter_count()
#     print(file_extent_name_letter_count_array)
#     print(file_extent_name_letter_count_array.shape)
