"""
返回每一个url中的参数中的最长的单词的长度
"""

import numpy as np


def get_arguments_longest_word_length():
    return np.zeros((12590, ), dtype=int)


# if __name__ == '__main__':
#     arguments_longest_word_array = get_arguments_longest_word_length()
#     print(arguments_longest_word_array)
