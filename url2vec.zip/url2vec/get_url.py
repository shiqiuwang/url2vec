# 导入包
import pandas as pd


# 从原始数据中获取url列进行返回,返回值的数据类型是ndarray
def get_url():
    data = pd.read_csv('data//verified_online.csv')
    return data['url'].values

# if __name__ == '__main__':
#     data_url = get_url()
#     print(type(data_url))
