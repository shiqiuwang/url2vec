"""
判断一个url的ip地址是否含在域名里面，如果是返回1，如果不是返回0
"""
import numpy as np
from urllib.parse import urlparse
from get_url import get_url
from socket import gethostbyname


# 判断IP地址是否在域名里面
def is_ipaddress_in_domainname():
    # 获取url数组
    url_array = get_url()
    # 用于暂时存储ip地址是否在域名里面的值的列表
    is_ipaddress_in_domainname_list = []
    for url in url_array:
        try:
            host_name = urlparse(url).netloc
            ip = gethostbyname(host_name)
            if ip in host_name:
                is_ipaddress_in_domainname_list.append(1)
            else:
                is_ipaddress_in_domainname_list.append(0)
        except:
            is_ipaddress_in_domainname_list.append(0)
    is_ipaddress_in_domainname_array = np.array(is_ipaddress_in_domainname_list).reshape(-1, 1)
    return is_ipaddress_in_domainname_array


# # 主函数入口
# if __name__ == '__main__':
#     is_ipaddress_in_domainname_array = is_ipaddress_in_domainname()
#     print(is_ipaddress_in_domainname_array)
#     print(is_ipaddress_in_domainname_array.shape)
