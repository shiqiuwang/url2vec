"""
输入url 返回url里面对应的文件名的长度
"""
# 导入包
import numpy as np
import os
from get_url import get_url


def get_filename_length():
    # 获取url数组
    url_array = get_url()
    # 用于临时存储文件名长度的列表
    filename_length_list = []
    for url in url_array:
        filename = os.path.basename(url)
        # print(filename)
        # print(type(filename))
        filename_length_list.append(len(filename))
    filename_length_array = np.array(filename_length_list)
    return filename_length_array


# # 主函数入口
# if __name__ == '__main__':
#     filename_length_array = get_filename_length()
#     print(filename_length_array)
#     print(filename_length_array.shape)
