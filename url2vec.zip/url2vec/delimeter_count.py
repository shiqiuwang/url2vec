"""
返回url中的界定符的个数，最终返回界定符个数的数组
"""
from get_url import get_url
# from urllib.parse import urlparse
import re
import numpy as np

delimeter_count_list = []


def get_delimeter_count():
    # 获取url数组
    url_array = get_url()
    for url in url_array:
        # print(path)
        delimeter_count__list = re.findall(r"[\w']+", url)
        # print(path_token_list)
        delimeter_count_list.append(len(delimeter_count__list) - 1)
    delimeter_count_array = np.array(delimeter_count_list)
    return delimeter_count_array


# if __name__ == '__main__':
#     delimeter_count_array = get_delimeter_count()
#     print(delimeter_count_array)
#     print(delimeter_count_array.shape)
