"""
输入url,返回url的参数的长度，最终返回的是一个url参数长度的数组
"""
# 导入包
import numpy as np
from get_url import get_url
from urllib.parse import urlparse


# 定义获取参数长度数组的函数
def get_arg_length():
    # 获取url数组
    url_array = get_url()
    # 用于临时存储参数长度的列表
    arg_length_list = []
    for url in url_array:
        # print(url)
        arg = urlparse(url).params
        # print(arg)
        arg_length_list.append(len(arg))
    arg_length_array = np.array(arg_length_list)
    return arg_length_array


# # 主函数入口
# if __name__ == '__main__':
#     get_arg_array = get_arg_length()
#     print(get_arg_array)
#     print(get_arg_array.shape)
