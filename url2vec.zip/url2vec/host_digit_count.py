"""
输入url，返回host中的数值的个数，最终返回host中的数值个数的一个数组
"""
import numpy as np
from get_url import get_url
import re
from urllib.parse import urlparse


# 计算url中的数值个数的函数
def get_host_digit_count():
    # 获取url数组
    url_array = get_url()
    # 暂时存储host中的数值个数的列表
    host_digit_count_list = []
    for url in url_array:
        host_name = urlparse(url).netloc
        host_digit_count_list.append(len(re.findall('\d', host_name)))
    host_digit_count_array = np.array(host_digit_count_list)
    return host_digit_count_array


# # 主函数入口
# if __name__ == '__main__':
#     host_digit_count_array = get_host_digit_count()
#     print(host_digit_count_array)
#     print(host_digit_count_array.shape)
