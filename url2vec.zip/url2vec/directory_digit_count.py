"""
输入url，返回directory中的数值的个数，最终返回directory中的数值个数的一个数组
"""
# 导入包
import numpy as np
import os
from get_url import get_url
import re


def get_directory_digit_count():
    # 获取url数组
    url_array = get_url()
    # 用于临时存储文件目录中含有的数值的个数的列表
    directory_digit_count_list = []
    for url in url_array:
        dirname = os.path.dirname(url)
        directory_digit_count_list.append(len(re.findall('\d', dirname)))
        # print(filename)
        # print(type(filename))
        # directory_digit_count_list.append(len(dirname))
    directory_digit_count_array = np.array(directory_digit_count_list)
    return directory_digit_count_array


# # 主函数入口
# if __name__ == '__main__':
#     directory_digit_count_array = get_directory_digit_count()
#     print(directory_digit_count_array)
#     print(directory_digit_count_array.shape)
