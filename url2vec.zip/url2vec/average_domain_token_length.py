"""
针对每一个url，设置函数，输入为url，输出为url中domain中含有的token的平均长度，
将每一个url中的domain含有的token平均长度放到数组中，进行输出
"""
# 导入包
import re
from urllib.parse import urlparse
from get_url import get_url
import numpy as np

# 跟domain相关的关键词
topHostPostfix = (
    '.com', '.la', '.io', '.co', '.info', '.net', '.org', '.me', '.mobi',
    '.us', '.biz', '.xxx', '.ca', '.co.jp', '.com.cn', '.net.cn',
    '.org.cn', '.mx', '.tv', '.ws', '.ag', '.com.ag', '.net.ag',
    '.org.ag', '.am', '.asia', '.at', '.be', '.com.br', '.net.br',
    '.bz', '.com.bz', '.net.bz', '.cc', '.com.co', '.net.co',
    '.nom.co', '.de', '.es', '.com.es', '.nom.es', '.org.es',
    '.eu', '.fm', '.fr', '.gs', '.in', '.co.in', '.firm.in', '.gen.in',
    '.ind.in', '.net.in', '.org.in', '.it', '.jobs', '.jp', '.ms',
    '.com.mx', '.nl', '.nu', '.co.nz', '.net.nz', '.org.nz',
    '.se', '.tc', '.tk', '.tw', '.com.tw', '.idv.tw', '.org.tw',
    '.hk', '.co.uk', '.me.uk', '.org.uk', '.vg', ".com.hk")


# 返回每一个url的domain中的token的平均长度,
def get_average_domain_token_length():
    url_array = get_url()
    regx = r'[^\.]+(' + '|'.join([h.replace('.', r'\.') for h in topHostPostfix]) + ')$'
    pattern = re.compile(regx, re.IGNORECASE)

    # print("--" * 40)
    average_domain_token_length_list = []
    for url in url_array:
        parts = urlparse(url)
        host = parts.netloc
        m = pattern.search(host)
        res = m.group() if m else host
        domain_list = re.findall(r"[\w']+", res)
        total_len=0
        for token in domain_list:
            total_len+=len(token)
        average_domain_token_length_list.append(total_len/len(domain_list))
        # domain_token_count_list.append(len(domain_list))
    average_domain_token_length_array = np.array(average_domain_token_length_list)
    return average_domain_token_length_array


# if __name__ == '__main__':
#     average_domain_token_length_array= get_average_domain_token_length()
#     print(average_domain_token_length_array)
#     print(type(average_domain_token_length_array))
#     print(len(average_domain_token_length_array))
