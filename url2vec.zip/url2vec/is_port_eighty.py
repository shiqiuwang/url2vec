"""
输入url,判断url的端口号是否为80端口，如果是返回1，如果不是返回0，最后返回一个只含有0和1的数组
"""
# 导入包
import numpy as np
from urllib.request import build_opener
from get_url import get_url

opener = build_opener()
opener.addheaders = [('User-agent',
                      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36')]


# 获取端口号的函数


def is_port_eighty():
    # 获取url数组
    url_array = get_url()
    # 暂时存储url端口号的列表
    is_port_eighty_list = []
    for url in url_array:
        try:
            response = opener.open(url, timeout=10)
            port = response.fp.raw._sock.getpeername()[-1]
            if port == 80:
                is_port_eighty_list.append(1)
            else:
                is_port_eighty_list.append(0)
        except:
            is_port_eighty_list.append(0)
    is_port_eighty_array = np.array(is_port_eighty_list).reshape(-1, 1)
    return is_port_eighty_array


# # 主函数入口
# if __name__ == '__main__':
#     is_port_eighty_array = is_port_eighty()
#     print(is_port_eighty_array)
#     print(is_port_eighty_array.shape)
