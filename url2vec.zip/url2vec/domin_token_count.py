"""
针对每一个url，设置函数，一个返回每一个url的domain，另一个针对返回的domain数组，返回每一个url的domain里面的token个数
"""
# 导入包
import re
from urllib.parse import urlparse
from get_url import get_url
import numpy as np

# 跟domain相关的关键词
topHostPostfix = (
    '.com', '.la', '.io', '.co', '.info', '.net', '.org', '.me', '.mobi',
    '.us', '.biz', '.xxx', '.ca', '.co.jp', '.com.cn', '.net.cn',
    '.org.cn', '.mx', '.tv', '.ws', '.ag', '.com.ag', '.net.ag',
    '.org.ag', '.am', '.asia', '.at', '.be', '.com.br', '.net.br',
    '.bz', '.com.bz', '.net.bz', '.cc', '.com.co', '.net.co',
    '.nom.co', '.de', '.es', '.com.es', '.nom.es', '.org.es',
    '.eu', '.fm', '.fr', '.gs', '.in', '.co.in', '.firm.in', '.gen.in',
    '.ind.in', '.net.in', '.org.in', '.it', '.jobs', '.jp', '.ms',
    '.com.mx', '.nl', '.nu', '.co.nz', '.net.nz', '.org.nz',
    '.se', '.tc', '.tk', '.tw', '.com.tw', '.idv.tw', '.org.tw',
    '.hk', '.co.uk', '.me.uk', '.org.uk', '.vg', ".com.hk")


# 返回每一个url的domain,
def get_domian_token_count():
    url_array = get_url()
    regx = r'[^\.]+(' + '|'.join([h.replace('.', r'\.') for h in topHostPostfix]) + ')$'
    pattern = re.compile(regx, re.IGNORECASE)

    # print("--" * 40)
    domain_token_count_list = []
    for url in url_array:
        parts = urlparse(url)
        host = parts.netloc
        m = pattern.search(host)
        res = m.group() if m else host
        domain_list=re.findall(r"[\w']+", res)
        domain_token_count_list.append(len(domain_list))
    domain_token_count_array = np.array(domain_token_count_list)
    return domain_token_count_array

#
# if __name__ == '__main__':
#     domain_token_count_array = get_domian()
#     print(domain_token_count_array)
#     print(type(domain_token_count_array))
#     print(len(domain_token_count_array))
