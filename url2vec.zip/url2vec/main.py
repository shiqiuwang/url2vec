# 导入包
import pandas as pd
from query_length import get_query_length
from domin_token_count import get_domian_token_count
from path_token_count import get_path_token_count
from average_domain_token_length import get_average_domain_token_length
from long_domain_token_length import get_long_domain_token_length
from average_path_token_length import get_average_path_token_length
from tld import get_url_tld
from url_length import get_url_length
from domain_length import get_domain_length
from path_length import get_path_length
from filename_length import get_filename_length
from extension_length import get_extension_length
from arg_length import get_arg_length
from is_port_eighty import is_port_eighty
from number_of_dots_in_url import get_number_of_dots_in_url
from is_ipaddress_in_domainname import is_ipaddress_in_domainname
from url_digit_count import get_url_digit_count
from host_digit_count import get_host_digit_count
from directory_digit_count import get_directory_digit_count
from filename_digit_count import get_filename_digit_count
from extension_digit_count import get_file_extent_name_digit_count
from query_digit_count import get_query_digit_count
from url_letter_count import get_url_letter_count
from host_letter_count import get_host_letter_count
from directory_letter_count import get_directory_letter_count
from filename_letter_count import get_filename_letter_count
from extension_letter_count import get_file_extent_name_letter_count
from query_letter_count import get_query_letter_count
from longest_path_token_length import get_longest_path_token_length
from domain_longest_word_length import get_domain_longest_word_length
from path_longest_word_length import get_path_longest_word_length
from arguments_longest_word_length import get_arguments_longest_word_length
from delimeter_count import get_delimeter_count
from number_rate_url import get_number_rate_url
from number_rate_domain import get_number_rate_domain
from number_rate_directory import get_number_rate_directory
from number_rate_file_name import get_number_rate_filename
from number_rate_extension import get_number_rate_extension

query_length_array = get_query_length()
domain_token_count_array = get_domian_token_count()
path_token_count_array = get_path_token_count()
average_domain_token_length_array = get_average_domain_token_length()
long_domain_token_length_array = get_long_domain_token_length()
average_path_token_length_array = get_average_path_token_length()
url_tld_value_array = get_url_tld()
url_length_array = get_url_length()
domain_length_array = get_domain_length()
path_length_array = get_path_length()
filename_length_array = get_filename_length()
extension_array = get_extension_length()
arg_array = get_arg_length()
# is_port_eighty_array = is_port_eighty()
number_of_dots_in_url_array = get_number_of_dots_in_url()
# is_ipaddress_in_domainname_array = is_ipaddress_in_domainname()
url_digit_count_array = get_url_digit_count()
host_digit_count_array = get_host_digit_count()
directory_digit_count_array = get_directory_digit_count()
filename_digit_count_array = get_filename_digit_count()
file_extent_name_digit_count_array = get_file_extent_name_digit_count()
query_digit_count_array = get_query_digit_count()
url_letter_count_array = get_url_letter_count()
host_letter_count_array = get_host_letter_count()
directory_letter_count_array = get_directory_letter_count()
filename_letter_count_array = get_filename_letter_count()
file_extent_name_letter_count_array = get_file_extent_name_letter_count()
query_letter_count_array = get_query_letter_count()
longest_path_token_length_array = get_longest_path_token_length()
domain_longest_word_length_array = get_domain_longest_word_length()
path_longest_word_length_array = get_path_longest_word_length()
arguments_longest_word_array = get_arguments_longest_word_length()
delimeter_count_array = get_delimeter_count()
number_rate_url_array = get_number_rate_url()
number_rate_domain_array = get_number_rate_domain()
number_rate_directory_array = get_number_rate_directory()
number_rate_filename_array = get_number_rate_filename()
number_rate_extension_array = get_number_rate_extension()

url_vec = pd.DataFrame(
    columns=["Querylength", "domain_token_count", "path_token_count",
             "avgdomaintokenlen", "longdomaintokenlen",
             "avgpathtokenlen", "tld", "urlLen", "domainlength",
             "pathLength", "fileNameLen", "this.fileExtLen",
             "ArgLen", "NumberofDotsinURL", "URL_DigitCount",
             "host_DigitCount", "Directory_DigitCount",
             "File_name_DigitCount", "Extension_DigitCount",
             "Query_DigitCount", "URL_Letter_Count", "host_letter_count",
             "Directory_LetterCount", "Filename_LetterCount", "Extension_LetterCount",
             "Query_LetterCount", "LongestPathTokenLength", "Domain_LongestWordLength",
             "Path_LongestWordLength", "Arguments_LongestWordLength", "delimeter_Count",
             "NumberRate_URL", "NumberRate_Domain", "NumberRate_DirectoryName",
             "NumberRate_FileName", "NumberRate_Extension"])
url_vec["Querylength"] = query_length_array
url_vec["domain_token_count"] = domain_token_count_array
url_vec["path_token_count"] = path_token_count_array
url_vec["avgdomaintokenlen"] = average_domain_token_length_array
url_vec["longdomaintokenlen"] = long_domain_token_length_array
url_vec["avgpathtokenlen"] = average_path_token_length_array
url_vec["tld"] = url_tld_value_array
url_vec["urlLen"] = url_length_array
url_vec["domainlength"] = domain_length_array
url_vec["pathLength"] = path_length_array
url_vec["fileNameLen"] = filename_length_array
url_vec["this.fileExtLen"] = extension_array
url_vec["ArgLen"] = arg_array
# url_vec["isPortEighty"] = is_port_eighty_array
url_vec["NumberofDotsinURL"] = number_of_dots_in_url_array
# url_vec["ISIpAddressInDomainName"] = is_ipaddress_in_domainname_array
url_vec["URL_DigitCount"] = url_digit_count_array
url_vec["host_DigitCount"] = host_digit_count_array
url_vec["Directory_DigitCount"] = directory_digit_count_array
url_vec["File_name_DigitCount"] = filename_digit_count_array
url_vec["Extension_DigitCount"] = file_extent_name_digit_count_array
url_vec["Query_DigitCount"] = query_digit_count_array
url_vec["URL_Letter_Count"] = url_letter_count_array
url_vec["host_letter_count"] = host_letter_count_array
url_vec["Directory_LetterCount"] = directory_letter_count_array
url_vec["Filename_LetterCount"] = filename_letter_count_array
url_vec["Extension_LetterCount"] = file_extent_name_letter_count_array
url_vec["Query_LetterCount"] = query_letter_count_array
url_vec["LongestPathTokenLength"] = longest_path_token_length_array
url_vec["Domain_LongestWordLength"] = domain_longest_word_length_array
url_vec["Path_LongestWordLength"] = path_longest_word_length_array
url_vec["Arguments_LongestWordLength"] = arguments_longest_word_array
url_vec["delimeter_Count"] = delimeter_count_array
url_vec["NumberRate_URL"] = number_rate_url_array
url_vec["NumberRate_Domain"] = number_rate_domain_array
url_vec["NumberRate_DirectoryName"] = number_rate_directory_array
url_vec["NumberRate_FileName"] = number_rate_filename_array
url_vec["NumberRate_Extension"] = number_rate_extension_array
url_vec.to_csv("D:\\PycharmProjects\\url2vec\\data\\url_vector.csv", index=False)
