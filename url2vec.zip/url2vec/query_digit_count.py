"""
给定url，返回每一个url的query中含有的数值的个数，最终返回的是所有url的query中含有的数值的个数的ndarray
"""
# 导入包
import numpy as np
from get_url import get_url
from urllib.parse import urlparse
import re


# 计算请求url的query中含有数值的个数
def get_query_digit_count():
    # 用于临时存储请求query中的数值的个数的列表
    query_digit_count_list = []
    # 获取url数组
    url_array = get_url()
    # 对每一个url的query的数值的个数进行计算，并追加到query_digit_count_list列表中，最后再将列表转为ndarry数据类型
    for url in url_array:
        query = urlparse(url).query
        # print(type(query))#"str"
        query_digit_count_list.append(len(re.findall('\d', query)))
    query_digit_count_array = np.array(query_digit_count_list)

    return query_digit_count_array

# if __name__ == '__main__':
#     query_digit_count_array = get_query_digit_count()
#     print(query_digit_count_array)
#     print(query_digit_count_array.shape)
