"""
给定url，返回每一个url中的字母的个数，最终返回的是所有url中的字母的个数的ndarray
"""
# 导入包
import numpy as np
from get_url import get_url
import re


# 获取请求url中的字母的个数
def get_url_letter_count():
    # 用于临时存储请求url中的字母的个数的列表
    url_letter_count_list = []
    # 获取url数组
    url_array = get_url()
    # 对每一个url中的字母的个数进计算，并追加到url_letter_count_list列表中，最后再将列表转为ndarry数据类型
    for url in url_array:
        url_letter_count_list.append(len(re.findall('[a-zA-Z]', url)))
    url_letter_count_array = np.array(url_letter_count_list)

    return url_letter_count_array

# if __name__ == '__main__':
#     url_letter_count_array = get_url_letter_count()
#     print(url_letter_count_array)
#     print(len(url_letter_count_array))
