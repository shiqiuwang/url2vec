"""
给定url，返回每一个url的长度，最终返回的是所有url长度的一个ndarray
"""
# 导入包
import numpy as np
from get_url import get_url


# 获取请求url的长度
def get_url_length():
    # 用于临时存储请求url的长度
    url_length_list = []
    # 获取url数组
    url_array = get_url()
    # 对每一个url进行长度的计算，并追加到url_length_list列表中，最后再将列表转为ndarry数据类型
    for url in url_array:
        url_length_list.append(len(url))
    url_length_array = np.array(url_length_list)

    return url_length_array

# if __name__=='__main__':
#     query_length_array=get_query_length()
#     print(len(query_length_array))
