"""
返回extension中的数字个数占extension长度的比值，最终返回一个比值数组
"""
# 导入包
import numpy as np
import os
from get_url import get_url
import re


def get_number_rate_extension():
    # 获取url数组
    url_array = get_url()
    # 用于临时存储文件拓展名中的数值个数的列表
    number_rate_extension_list = []
    for url in url_array:
        file_extent_name = os.path.splitext(url)[1]
        if len(file_extent_name) != 0:
            number_rate_extension_list.append(len(re.findall('\d', file_extent_name)) / len(file_extent_name))
        else:
            number_rate_extension_list.append(0)
        # print(file_extent_name)
        # number_rate_extension_list.append(len(file_extent_name))
    number_rate_extension_array = np.array(number_rate_extension_list)
    return number_rate_extension_array

# # 主函数入口
# if __name__ == '__main__':
#     number_rate_extension_array = get_number_rate_extension()
#     print(number_rate_extension_array)
#     print(number_rate_extension_array.shape)
