"""
返回directory中的数字个数占url长度的比值，最终返回一个比值数组
"""
# 导入包
import numpy as np
import os
from get_url import get_url
import re


def get_number_rate_filename():
    # 获取url数组
    url_array = get_url()
    # 用于临时存储文件名长度的列表
    number_rate_filename_list = []
    for url in url_array:
        filename = os.path.basename(url)
        if len(filename) != 0:
            number_rate_filename_list.append(len(re.findall('\d', filename)) / len((filename)))
        else:
            number_rate_filename_list.append(0)
        # print(filename)
        # print(type(filename))
        # number_rate_filename_list.append(len(dirname))
    number_rate_filename_array = np.array(number_rate_filename_list)
    return number_rate_filename_array


# 主函数入口
# if __name__ == '__main__':
#     number_rate_filename_array = get_number_rate_filename()
#     print(number_rate_filename_array)
#     print(number_rate_filename_array.shape)
