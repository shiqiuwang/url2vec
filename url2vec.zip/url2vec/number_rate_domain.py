"""
返回domain中的数字个数占url长度的比值，最终返回一个比值数组
"""
import numpy as np
from get_url import get_url
import re
from urllib.parse import urlparse


# 计算url中的数值个数的函数
def get_number_rate_domain():
    # 获取url数组
    url_array = get_url()
    # 暂时存储host中的数值个数的列表
    number_rate_domain_list = []
    for url in url_array:
        host_name = urlparse(url).netloc
        number_rate_domain_list.append(len(re.findall('\d', host_name))/len(host_name))
    number_rate_domain_array = np.array(number_rate_domain_list)
    return number_rate_domain_array


# 主函数入口
# if __name__ == '__main__':
#     number_rate_domain_array = get_number_rate_domain()
#     print(number_rate_domain_array)
#     print(number_rate_domain_array.shape)
