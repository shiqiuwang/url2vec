"""
返回每一个url的路径中的最长的token的长度，最终要求返回的是每一个url的路径中t最长的token的长度的ndarray
"""
from get_url import get_url
from urllib.parse import urlparse
import re
import numpy as np

path_longest_word_length_list = []


def get_path_longest_word_length():
    # 获取url数组
    url_array = get_url()
    for url in url_array:
        path = urlparse(url).path
        # print(path)
        path_token_list = re.findall(r"[\w']+", path)
        # print(path_token_list)
        if path_token_list != []:
            path_longest_word_length_list.append(max(list(map(len, path_token_list))))
        else:
            path_longest_word_length_list.append(0)
    path_longest_word_length_array = np.array(path_longest_word_length_list)
    return path_longest_word_length_array

# if __name__ == '__main__':
#     path_longest_word_length_array = get_path_longest_word_length()
#     print(path_longest_word_length_array)
#     print(path_longest_word_length_array.shape)
