"""
给定url，返回每一个url的query的长度，最终返回的是所有url的query的长度的一个ndarray
"""
# 导入包
import numpy as np
from get_url import get_url
from urllib.parse import urlparse


# 获取请求url的query的长度
def get_query_length():
    # 用于临时存储请求query的长度
    query_length_list = []
    # 获取url数组
    url_array = get_url()
    # 对每一个url的query进行长度的计算，并追加到query_length_list列表中，最后再将列表转为ndarry数据类型
    for url in url_array:
        query = urlparse(url).query
        # print(type(query))#"str"
        query_length_list.append(len(query))
    query_length_array = np.array(query_length_list)

    return query_length_array

# if __name__=='__main__':
#     query_length_array=get_query_length()
#     print(query_length_array)
#     print(len(query_length_array))
