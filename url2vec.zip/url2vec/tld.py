"""
提取每一个url的tld,并将tld进行向量化，作为数组进行返回
"""
from get_url import get_url
# from tld import get_tld

from gensim.models import word2vec
import numpy as np
import pandas as pd

# import operator
# from functools import reduce

# 构建模型
sentences = word2vec.Text8Corpus(u'data//url_tld.txt')
model = word2vec.Word2Vec(sentences, min_count=1, size=50)
url_tld_value_list = []
url_tld_array = pd.read_table('data//url_tld.txt',header=None).values
# print(url_tld_array.shape)


# url_tld_array = reduce(operator.add, url_tld_array)
#
# print(url_tld_array)
# print(type(url_tld_array))
# print(url_tld_array.shape)

def get_url_tld():
    for url_tld in url_tld_array:
        try:
            url_tld_vec = model[url_tld[0]]
            url_tld_value = url_tld_vec.mean()
            url_tld_value_list.append(url_tld_value)
        except:
            url_tld_value_list.append(0)
    url_tld_value_array = np.array(url_tld_value_list)
    return url_tld_value_array


# if __name__ == '__main__':
#     url_tld_value_array = get_url_tld()
#     print(url_tld_value_array)
#     print(type(url_tld_value_array))
#     print(url_tld_value_array.shape)
