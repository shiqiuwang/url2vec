"""
输入url，返回filename中的数值的个数，最终返回filename中的数值个数的一个数组
"""
# 导入包
import numpy as np
import os
from get_url import get_url
import re


def get_filename_digit_count():
    # 获取url数组
    url_array = get_url()
    # 用于临时存储文件名长度的列表
    filename_digit_count_list = []
    for url in url_array:
        filename = os.path.basename(url)
        filename_digit_count_list.append(len(re.findall('\d', filename)))
        # print(filename)
        # print(type(filename))
        # filename_digit_count_list.append(len(dirname))
    filename_digit_count_array = np.array(filename_digit_count_list)
    return filename_digit_count_array
#
# # 主函数入口
# if __name__ == '__main__':
#     filename_digit_count_array = get_filename_digit_count()
#     print(filename_digit_count_array)
#     print(filename_digit_count_array.shape)
