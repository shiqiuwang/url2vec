"""
返回每一个url的path的长度，最终要求返回的是每一个url的path的长度的ndarray
"""
from get_url import get_url
from urllib.parse import urlparse
# import re
import numpy as np

path_length_list = []


def get_path_length():
    # 获取url数组
    url_array = get_url()
    for url in url_array:
        path = urlparse(url).path
        path_length_list.append(len(path))
        # print(path)
        # path_token_list = re.findall(r"[\w']+", path)
        # if path_token_list!=[]:
        #     average_path_token_length = np.mean(list(map(len, path_token_list)))
        #     average_path_token_length_list.append(average_path_token_length)
        # else:
        #     average_path_token_length_list.append(0)
    path_length_array = np.array(path_length_list)
    return path_length_array


# if __name__ == '__main__':
#     path_length_array = get_path_length()
#     print(path_length_array)
#     print(path_length_array.shape)
#     print(type(path_length_array))
