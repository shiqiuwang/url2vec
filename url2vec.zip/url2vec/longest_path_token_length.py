"""
返回每一个url的路径中的长度最长的token的长度，最终要求返回的是每一个url的路径中最长的token的长度的ndarray
"""
from get_url import get_url
from urllib.parse import urlparse
import re
import numpy as np

longest_path_token_length_list = []


def get_longest_path_token_length():
    # 获取url数组
    url_array = get_url()
    for url in url_array:
        path = urlparse(url).path
        # print(path)
        path_token_list = re.findall(r"[\w']+", path)
        # print(path_token_list)
        if path_token_list != []:
            longest_path_token_length_list.append(max(list(map(len, path_token_list))))
        else:
            longest_path_token_length_list.append(0)
    longest_path_token_length_array = np.array(longest_path_token_length_list)
    return longest_path_token_length_array

#
# if __name__ == '__main__':
#     longest_path_token_length_array = get_longest_path_token_length()
#     print(longest_path_token_length_array)
#     print(longest_path_token_length_array.shape)
