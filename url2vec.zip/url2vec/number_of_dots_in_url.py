"""
输入url,输出url中的
"""
# 导入包
import numpy as np
from get_url import get_url
import re


# 统计url中点的个数
def get_number_of_dots_in_url():
    # 获取url数组
    url_array = get_url()
    # 暂时存储url中的点的个数的列表
    number_of_dots_in_url_list = []
    for url in url_array:
        number_of_dots_in_url_list.append(len(re.findall('\.', url)))
    number_of_dots_in_url_array = np.array(number_of_dots_in_url_list)
    return number_of_dots_in_url_array


# # 主函数
# if __name__ == '__main__':
#     number_of_dots_in_url_array = get_number_of_dots_in_url()
#     print(number_of_dots_in_url_array)
#     print(number_of_dots_in_url_array.shape)
