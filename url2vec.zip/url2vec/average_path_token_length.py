"""
返回每一个url的path中的token的平均长度，最终要求返回的是每一个url的路径中token的平均长度的ndarray
"""
from get_url import get_url
from urllib.parse import urlparse
import re
import numpy as np

average_path_token_length_list = []


def get_average_path_token_length():
    # 获取url数组
    url_array = get_url()
    for url in url_array:
        path = urlparse(url).path
        # print(path)
        path_token_list = re.findall(r"[\w']+", path)
        if path_token_list!=[]:
            average_path_token_length = np.mean(list(map(len, path_token_list)))
            average_path_token_length_list.append(average_path_token_length)
        else:
            average_path_token_length_list.append(0)
    average_path_token_length_array = np.array(average_path_token_length_list)
    return average_path_token_length_array


# if __name__ == '__main__':
#     average_path_token_length_array = get_average_path_token_length()
#     print(average_path_token_length_array)
#     print(average_path_token_length_array.shape)
#     print(type(average_path_token_length_array))
