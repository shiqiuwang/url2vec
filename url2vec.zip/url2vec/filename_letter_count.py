"""
输入url，返回filename中的字母的个数，最终返回filename中的字母个数的一个数组
"""
# 导入包
import numpy as np
import os
from get_url import get_url
import re


def get_filename_letter_count():
    # 获取url数组
    url_array = get_url()
    # 用于临时存储文件名中含有的字母的个数的列表
    filename_letter_count_list = []
    for url in url_array:
        filename = os.path.basename(url)
        filename_letter_count_list.append(len(re.findall('[a-zA-Z]', filename)))
        # print(filename)
        # print(type(filename))
        # filename_letter_count_list.append(len(dirname))
    filename_letter_count_array = np.array(filename_letter_count_list)
    return filename_letter_count_array


# # 主函数入口
# if __name__ == '__main__':
#     filename_letter_count_array = get_filename_letter_count()
#     print(filename_letter_count_array)
#     print(filename_letter_count_array.shape)
